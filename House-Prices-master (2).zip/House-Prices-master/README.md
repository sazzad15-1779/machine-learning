# Housing price prediction model
This is a Housing price prediction model based on the Kaggle competition.
The train.csv and test.csv contains the training data and the data on which the testing on model is to be performed.
The data_description.txt contains the description of the data.

## Dependencies:
* Python 3.5
* Pandas
* Scikit-learn
